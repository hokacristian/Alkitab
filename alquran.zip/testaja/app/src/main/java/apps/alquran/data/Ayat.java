package apps.alquran.data;

public class Ayat {
    private String ar;
    private String id;
    private String tr;
    private String nomor;

    public String getAr() {
        return ar;
    }

    public String getId() {
        return id;
    }

    public String getTr() {
        return tr;
    }

    public String getNomor() {
        return nomor;
    }
}